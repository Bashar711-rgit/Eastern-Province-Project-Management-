-- السؤال 1
SELECT c.challan_no, c.challan_date
FROM challan c
JOIN challan_details cd ON c.challan_no = cd.challan_no
WHERE cd.product_no = 'P07965';

-- السؤال 2
SELECT challan_no, order_no
FROM challan_details
WHERE qty_disp = 10;