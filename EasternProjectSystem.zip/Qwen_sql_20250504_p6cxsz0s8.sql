CREATE TABLE product_master (
    product_no VARCHAR(10) PRIMARY KEY
);

CREATE TABLE challan (
    challan_no VARCHAR(10) PRIMARY KEY,
    challan_date DATE
);

CREATE TABLE challan_details (
    challan_no VARCHAR(10),
    product_no VARCHAR(10),
    qty_disp INT,
    order_no VARCHAR(10),
    FOREIGN KEY (challan_no) REFERENCES challan(challan_no),
    FOREIGN KEY (product_no) REFERENCES product_master(product_no)
);

INSERT INTO product_master (product_no) VALUES
('P00001'), ('P03453'), ('P07868'), ('P07885'), ('P07965'), ('P07975');

INSERT INTO challan (challan_no, challan_date) VALUES
('CH1001', '2023-10-01'), ('CH1002', '2023-10-02'),
('CH1003', '2023-10-03'), ('CH1004', '2023-10-04');

INSERT INTO challan_details (challan_no, product_no, qty_disp, order_no) VALUES
('CH1001', 'P00001', 5, 'SO1001'),
('CH1002', 'P07965', 10, 'SO1002'),
('CH1003', 'P07885', 10, 'SO1003'),
('CH1004', 'P07975', 15, 'SO1004');